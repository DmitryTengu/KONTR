﻿using System;
namespace ClaTest
{    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine((char)1);
            Console.CursorVisible = false;
            Wall wall = new Wall();
            Cactus cactus = new Cactus();
            IDrawable d = wall;
            IDrawable x = cactus;
            d.Draw();
            x.Draw();

            Console.ReadKey();
            //user около препятствия HARM/UNHARM
        }
    }
}
