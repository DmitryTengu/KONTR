﻿using System;

namespace ClaTest
{
    class Wall : Let, IDrawable
    {
        void IDrawable.Draw()
        {
        
            Random RTemp = new Random();
            int Temp = RTemp.Next(2);
            int X = RTemp.Next(3, 15);
            int Y = RTemp.Next(3, 15);
            Damage = RTemp.Next(9);
            Console.SetCursorPosition(X, Y);

                Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(@"#Wall#");
            Console.SetCursorPosition(X, Y + 1);
            Console.WriteLine(Damage);
            Console.ResetColor();
        }

    }
}
