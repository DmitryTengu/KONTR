﻿using System;


namespace ClaTest
{
    abstract class Let : IDrawable
    {
        protected int Damage { get; set; }
        protected bool IsHurt()
        {
            return new Random().Next(2) == 0;
        }

        void IDrawable.Draw()
        {
            Console.WriteLine((char)1);
        }


    }
}
