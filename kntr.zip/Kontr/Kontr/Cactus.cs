﻿using System;


namespace ClaTest
{
    class Cactus : Let, IHarmable, IDrawable
    {

        void IDrawable.Draw()
        {
            
            Random RTemp = new Random();
            int Temp = RTemp.Next(2);
            int X = RTemp.Next(3, 15);
            int Y = RTemp.Next(3, 15);
            Damage = RTemp.Next(9);
            Console.SetCursorPosition(X+5, Y);
                Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"#Cactus#");
            Console.SetCursorPosition(X+5, Y + 1);
            Console.WriteLine(Damage);
            Console.ResetColor();

        }

        void IHarmable.DoHarm()
        { }

    }
}
