﻿using System;

namespace ClaTest
{
    interface IHarmable
    {
        void DoHarm();
    }
    interface IDrawable
    {
        void Draw();
    }
}
